/**
 * 
 */
/**
 * 
 */
module HospitalManagementSystem {
	requires java.sql;
}